// Sphere
if (model1->getVelocity()) {
	v = model1->getVelocity();
	model1->move(v, 0, 0);
	model1->rotateZX(-v / model1->getRadius());
	new_v = v + model1->getAcceleration();
	model1->setVelocity(new_v * v < 0 ? 0 : new_v);
}

// Mayatnik
v = model2->getVelocity();
if (v)
	model2->rotateZX(v / model2->getRadius());
if (m2_v0) {
	new_v = pow(m2_v0, 2) - 2 * G * model2->getRadius() * (1 - cos(model2->getAngle()));
	if (new_v < 0)
		m2_speed_vect *= -1;
	new_v = sqrt(abs(new_v));
	model2->setVelocity(new_v * m2_speed_vect);
}

// Button
if (model3->getVelocity()) {
	v = model3->getVelocity();
	new_v = v + model3->getAcceleration();
	model3->setVelocity(new_v * v < 0 ? 0 : new_v, MU_BUTTON);
	v = model3->getVelocity();
	model3->move(v, 0, 0);
}

// Domino
v = dominos[9]->getVelocity();
if (v)
	dominos[9]->rotateZX(-v / dominos[9]->getRadius());
if (dominoV0[9]) {
	new_v = sqrt(abs(pow(dominoV0[9], 2) + 2 * G * dominos[9]->getRadius() * (1 - sin(dominos[9]->getAngle()))));
	if (dominos[9]->getAngle() - new_v / dominos[9]->getRadius() < 0) {
		dominoV0[9] = 0;
		dominoMoving[9] = 0;
		dominoEnded[9] = 1;
		dominos[9]->rotateZX(-dominos[9]->getAngle());
		new_v = 0;
	}
	dominos[9]->setVelocity(new_v);
}
for (int i = 8; i > -1; i--) {
	v = dominos[i]->getVelocity();
	if (v > 0)
		dominos[i]->rotateZX(-v / dominos[i]->getRadius());
	if (dominoMoving[i]) {
		new_v = sqrt(abs(pow(dominoV0[i], 2) + 2 * G * dominos[i]->getRadius() * (1 - sin(dominos[i]->getAngle()))));
		fin_angle = atan(dominos[i + 1]->getWidth() / SPACE_BETWEEN_DOMINO);
		collision_angle = acos((SPACE_BETWEEN_DOMINO - dominos[i + 1]->getWidth()) / dominos[i]->getRadius());
		new_angle = dominos[i]->getAngle() - new_v / dominos[i]->getRadius();
		collAngle = dominos[i]->findCollisionAngle(dominos[i + 1]);

		Dot rotatedRightUp = dominos[i]->getRightUp();
		rotatedRightUp.rotateY(new_angle, dominos[i]->getCenter());

		if (!dominoMoving[i + 1] && !dominoEnded[i + 1] && new_angle < collision_angle) {
			dominos[i]->rotateZX(-dominos[i]->getAngle() + collision_angle);
		}
		else if (!dominoEnded[i + 1] && new_angle < collAngle) {
			dominos[i]->rotateZX(-dominos[i]->getAngle() + collAngle);
		}
		else if (dominoEnded[i + 1] && new_angle < fin_angle) {
			dominoV0[i] = 0;
			dominoMoving[i] = 0;
			dominoEnded[i] = 1;
			dominos[i]->rotateZX(-dominos[i]->getAngle() + fin_angle);
			new_v = 0;
		}
		dominos[i]->setVelocity(new_v);
	}
}

// Collision sphere and mayatnik
if (model2->getCollisionCenter().findDistance(model1->getCollisionCenter()) <= model2->getCollisionRadius() + model1->getCollisionRadius()) {
	double v0 = model1->getVelocity();
	double m1 = model1->getMass();
	double m2 = model2->getMass();
	m2_v0 = 2 * m1 / (m1 + m2) * v0;
	model1->setVelocity((m1 - m2) / (m1 + m2) * v0);
	model2->setVelocity(m2_v0);
}

// Collision mayatnik and domino
if (dominos.front()->getLeftUp().getZ() >= model2->getCollisionCenter().getZ() && model2->getCollisionCenter().findDistanceToLine(dominos[0]->getLeftUp(), dominos[0]->getLeftDown()) <= model2->getCollisionRadius()) {
	double v0 = model2->getVelocity();
	double m1 = model2->getMass();
	double m2 = dominos[0]->getMass();
	dominoMoving[0] = 1;
	dominoV0[0] = 2 * m1 / (m1 + m2) * v0;
	model2->setVelocity((m1 - m2) / (m1 + m2) * v0);
	dominos[0]->setVelocity(dominoV0[0]);
}

// Collision domino and domino
for (int i = 8; i > -1; i--) {
	if (!dominoEnded[i + 1] && dominos[i]->getRightUp().findDistanceToLine(dominos[i + 1]->getLeftUp(), dominos[i + 1]->getLeftDown()) <= DIST_EPS) {
		double v0 = dominos[i]->getVelocity();
		double m1 = dominos[i]->getMass();
		double m2 = dominos[i + 1]->getMass();
		dominoV0[i] = (m1 - m2) / (m1 + m2) * v0;
		dominoV0[i + 1] = 2 * m1 / (m1 + m2) * v0;
		dominoMoving[i + 1] = 1;
		dominos[i]->setVelocity(dominoV0[i]);
		dominos[i + 1]->setVelocity(dominoV0[i + 1]);
	}
}

// Collision domino and button
if (dominos.back()->getRightUp().getZ() >= model3->getLeftDown().getZ() && dominos.back()->getRightUp().findDistanceToLine(model3->getLeftUp(), model3->getLeftDown()) <= DIST_EPS) {
	double v0 = dominos.back()->getVelocity();
	double m1 = dominos.back()->getMass();
	double m2 = model3->getMass();
	dominoV0.back() = (m1 - m2) / (m1 + m2) * v0;
	dominos.back()->setVelocity(dominoV0.back());
	model3->setVelocity(2 * m1 / (m1 + m2) * v0, MU_BUTTON);
}
