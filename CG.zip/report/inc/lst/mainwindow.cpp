#include "mainwindow.h"
#include "ui_mainwindow.h"

//#define FLEX

#include "QDebug"
#include <QErrorMessage>
#include <QShortcut>
#include <QTimer>
#include <QTime>

#ifdef FLEX
#include <QMediaPlayer>
#endif

#include "config.hpp"

#include "illuminantplacechooser.hpp"
#include "objecthangman.hpp"
#include "specialgraphicsview.hpp"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    facade = new UsageFacade;

#ifdef FLEX
    QMediaPlayer *player = new QMediaPlayer();
    player->setMedia(QUrl("../BigBabyTape.mp3"));
    player->play();
#endif

    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

    QWidget::connect(ui->graphicsView, SIGNAL(sendMouse(size_t, size_t)), this,
        SLOT(getMouseEvent(size_t, size_t)));

    QShortcut *shortcutDown = new QShortcut(QKeySequence("down"), this);
    QObject::connect(shortcutDown, SIGNAL(activated()), this, SLOT(pictureDown()));

    QShortcut *shortcutUp = new QShortcut(QKeySequence("up"), this);
    QObject::connect(shortcutUp, SIGNAL(activated()), this, SLOT(pictureUp()));

    QShortcut *shortcutLeft = new QShortcut(QKeySequence("left"), this);
    QObject::connect(shortcutLeft, SIGNAL(activated()), this, SLOT(pictureLeft()));

    QShortcut *shortcutRight = new QShortcut(QKeySequence("right"), this);
    QObject::connect(shortcutRight, SIGNAL(activated()), this, SLOT(pictureRight()));

    QShortcut *shortcutScaleUp = new QShortcut(QKeySequence("z"), this);
    QObject::connect(shortcutScaleUp, SIGNAL(activated()), this, SLOT(pictureScaleUp()));

    QShortcut *shortcutScaleDown = new QShortcut(QKeySequence("x"), this);
    QObject::connect(
        shortcutScaleDown, SIGNAL(activated()), this, SLOT(pictureScaleDown()));

    QShortcut *shortcutRotateXRight = new QShortcut(QKeySequence("s"), this);
    QObject::connect(
        shortcutRotateXRight, SIGNAL(activated()), this, SLOT(pictureRotateXRight()));

    QShortcut *shortcutRotateXLeft = new QShortcut(QKeySequence("w"), this);
    QObject::connect(
        shortcutRotateXLeft, SIGNAL(activated()), this, SLOT(pictureRotateXLeft()));

    QShortcut *shortcutRotateYRight = new QShortcut(QKeySequence("d"), this);
    QObject::connect(
        shortcutRotateYRight, SIGNAL(activated()), this, SLOT(pictureRotateYRight()));

    QShortcut *shortcutRotateYLeft = new QShortcut(QKeySequence("a"), this);
    QObject::connect(
        shortcutRotateYLeft, SIGNAL(activated()), this, SLOT(pictureRotateYLeft()));

    QShortcut *shortcutRotateZLeft = new QShortcut(QKeySequence("q"), this);
    QObject::connect(
        shortcutRotateZLeft, SIGNAL(activated()), this, SLOT(pictureRotateZLeft()));

    QShortcut *shortcutRotateZRight = new QShortcut(QKeySequence("e"), this);
    QObject::connect(
        shortcutRotateZRight, SIGNAL(activated()), this, SLOT(pictureRotateZRight()));
}

MainWindow::~MainWindow() { delete ui; }

void MainWindow::getMouseEvent(size_t x_, size_t y_)
{
    qDebug() << "Приняли ивент:" << x_ << y_ << '\n';
}

void MainWindow::pictureDown()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Крутим вниз";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene = facade->moveDownScene(MOVE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureUp()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Крутим вверх";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene = facade->moveUpScene(MOVE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureLeft()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Крутим влево";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene = facade->moveLeftScene(MOVE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRight()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Крутим вправо";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->moveRightScene(MOVE_UNIT, ui->graphicsView->rect());
    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureScaleUp()
{
    if (!facade->isSceneSet())
        return;
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();

    QGraphicsScene *setScene =
        facade->scaleScene(SCALE_VALUE + 1, ui->graphicsView->rect());
    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureScaleDown()
{
    if (!facade->isSceneSet())
        return;
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();

    QGraphicsScene *setScene =
        facade->scaleScene(1 - SCALE_VALUE, ui->graphicsView->rect());
    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateXRight()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по Х вниз";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateXScene(ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateXLeft()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по Х";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateXScene(-ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateYRight()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по Y";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateYScene(ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateYLeft()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по Y влево";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateYScene(-ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateZRight()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по z";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateZScene(ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureRotateZLeft()
{
    if (!facade->isSceneSet())
        return;
    qDebug() << "Вертим по z";
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene =
        facade->rotateZScene(-ROTATE_UNIT, ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::pictureToCenter()
{
    if (!facade->isSceneSet())
        return;

    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene = facade->toCenter(ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::on_pushButton_4_clicked()
{
    facade->setCellScene(13, 6);

    int retCode = 0;

    retCode = facade->addPendulum();
    retCode = facade->addSphere();
    retCode = facade->addCylindah();
    retCode = facade->addStand();
    retCode = facade->addButtonStand();
    for (int i = 0; i < 10; i++)
        retCode = facade->addDomino();

    on_pushButton_9_clicked();

    QGraphicsScene *setScene = facade->drawScene(ui->graphicsView->rect());

    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    ui->graphicsView->setScene(setScene);
    //    QTimer::singleShot(26, this, SLOT(updateScene()));
}

void MainWindow::on_pushButton_5_clicked()
{
}

void MainWindow::on_pushButton_clicked()
{
    if (!facade->isSceneSet())
    {
        QErrorMessage *err = new QErrorMessage();
        err->showMessage("Сцена ещё не была задана.");
        return;
    }

    IlluminantPlaceChooser placeChooserWindow(nullptr);
    placeChooserWindow.setModal(true);
    placeChooserWindow.exec();

    facade->addIlluminant(
        placeChooserWindow.getXAngle(), placeChooserWindow.getYAngle());

    QGraphicsScene *setScene = facade->drawScene(ui->graphicsView->rect());

    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    ui->graphicsView->setScene(setScene);
}

void MainWindow::on_pushButton_7_clicked()
{
    ObjectHangman objectHangmanWindow(facade->getScene(), nullptr);

    objectHangmanWindow.setModal(true);
    objectHangmanWindow.exec();

    QGraphicsScene *setScene = facade->drawScene(ui->graphicsView->rect());

    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    ui->graphicsView->setScene(setScene);
}

void MainWindow::on_pushButton_8_clicked()
{
    if (!facade->isSceneSet())
        return;
    if (ui->graphicsView->scene())
        delete ui->graphicsView->scene();
    QGraphicsScene *setScene = facade->toCenter(ui->graphicsView->rect());

    ui->graphicsView->setScene(setScene);
}

void MainWindow::on_pushButton_6_clicked()
{
    if (!facade->isSceneSet())
        return;

    PolModel *model1 = &(facade->getScene()->getModel(1)),
            *model2 = &(facade->getScene()->getModel(0)),
            *model3 = &(facade->getScene()->getModel(2));
    std::vector<PolModel*> dominos;
    std::vector<double> dominoV0;
    std::vector<int> dominoMoving, dominoEnded;
    for (size_t i = DOMINO_START; i < facade->getScene()->getModelsNum(); i++)
    {
        dominos.push_back(&(facade->getScene()->getModel(i)));
        dominoV0.push_back(0);
        dominoMoving.push_back(0);
        dominoEnded.push_back(0);
    }

    double m2_speed_vect = 1, v, new_v, old_v = 0;
    double m2_v0 = 0;
    double fin_angle, collision_angle, new_angle, collAngle;

    model1->setVelocity(40);

    while (model2->getVelocity() || model1->getVelocity()){
        // Sphere
        if (model1->getVelocity())
        {
            v = model1->getVelocity();
            model1->move(v, 0, 0);
            model1->rotateZX(-v / model1->getRadius());

            new_v = v + model1->getAcceleration();
            model1->setVelocity(new_v * v < 0 ? 0 : new_v);
        }
        // Mayatnik
        v = model2->getVelocity();
        if (v)
            model2->rotateZX(v / model2->getRadius());
        if (m2_v0)
        {
            new_v = pow(m2_v0, 2) - 2 * G * model2->getRadius() * (1 - cos(model2->getAngle()));
            if (new_v < 0)
                m2_speed_vect *= -1;
            new_v = sqrt(abs(new_v));
            model2->setVelocity(new_v * m2_speed_vect);
        }
        // Button
        if (model3->getVelocity())
        {
            v = model3->getVelocity();
            new_v = v + model3->getAcceleration();
            model3->setVelocity(new_v * v < 0 ? 0 : new_v, MU_BUTTON);
            v = model3->getVelocity();
            model3->move(v, 0, 0);
        }
        // Domino
        v = dominos[9]->getVelocity();
        if (v)
            dominos[9]->rotateZX(-v / dominos[9]->getRadius());
        if (dominoV0[9])
        {
            new_v = sqrt(abs(pow(dominoV0[9], 2) + 2 * G * dominos[9]->getRadius() * (1 - sin(dominos[9]->getAngle()))));
            if (dominos[9]->getAngle() - new_v / dominos[9]->getRadius() < 0)
            {
                dominoV0[9] = 0;
                dominoMoving[9] = 0;
                dominoEnded[9] = 1;
                dominos[9]->rotateZX(-dominos[9]->getAngle());
                new_v = 0;
            }
            dominos[9]->setVelocity(new_v);
        }
        // Domino
        for (int i = 8; i > -1; i--)
        {
            v = dominos[i]->getVelocity();
            if (v > 0)
                dominos[i]->rotateZX(-v / dominos[i]->getRadius());
            if (dominoMoving[i])
            {
                new_v = sqrt(abs(pow(dominoV0[i], 2) + 2 * G * dominos[i]->getRadius() * (1 - sin(dominos[i]->getAngle()))));
                fin_angle = atan(dominos[i + 1]->getWidth() / SPACE_BETWEEN_DOMINO);
                collision_angle = acos((SPACE_BETWEEN_DOMINO - dominos[i + 1]->getWidth()) / dominos[i]->getRadius());
                new_angle = dominos[i]->getAngle() - new_v / dominos[i]->getRadius();
                collAngle = dominos[i]->findCollisionAngle(dominos[i + 1]);

                Dot rotatedRightUp = dominos[i]->getRightUp();
                rotatedRightUp.rotateY(new_angle, dominos[i]->getCenter());

                if (!dominoMoving[i + 1] && !dominoEnded[i + 1] && new_angle < collision_angle)
                {
                    dominos[i]->rotateZX(-dominos[i]->getAngle() + collision_angle);
                }
                else if (!dominoEnded[i + 1] && new_angle < collAngle)
                {
                    dominos[i]->rotateZX(-dominos[i]->getAngle() + collAngle);
                }
                else if (dominoEnded[i + 1] && new_angle < fin_angle)
                {
                    dominoV0[i] = 0;
                    dominoMoving[i] = 0;
                    dominoEnded[i] = 1;
                    dominos[i]->rotateZX(-dominos[i]->getAngle() + fin_angle);
                    new_v = 0;
                }
                dominos[i]->setVelocity(new_v);
            }
        }

        // Collision sphere and mayatnik
        if (model2->getCollisionCenter().findDistance(model1->getCollisionCenter()) <=
                model2->getCollisionRadius() + model1->getCollisionRadius())
        {
            double v0 = model1->getVelocity();
            double m1 = model1->getMass();
            double m2 = model2->getMass();
            m2_v0 = 2 * m1 / (m1 + m2) * v0;
            model1->setVelocity((m1 - m2) / (m1 + m2) * v0);
            model2->setVelocity(m2_v0);
        }

        // Collision mayatnik and domino
        if (dominos.front()->getLeftUp().getZ() >= model2->getCollisionCenter().getZ() &&
                model2->getCollisionCenter().findDistanceToLine(dominos[0]->getLeftUp(), dominos[0]->getLeftDown()) <=
                model2->getCollisionRadius())
        {
            double v0 = model2->getVelocity();
            double m1 = model2->getMass();
            double m2 = dominos[0]->getMass();
            dominoMoving[0] = 1;
            dominoV0[0] = 2 * m1 / (m1 + m2) * v0;
            model2->setVelocity((m1 - m2) / (m1 + m2) * v0);
            dominos[0]->setVelocity(dominoV0[0]);
        }

        // Collision domino and domino
        for (int i = 8; i > -1; i--)
        {
            if (!dominoEnded[i + 1] &&
                    dominos[i]->getRightUp().findDistanceToLine(dominos[i + 1]->getLeftUp(), dominos[i + 1]->getLeftDown()) <= DIST_EPS)
            {
                double v0 = dominos[i]->getVelocity();
                double m1 = dominos[i]->getMass();
                double m2 = dominos[i + 1]->getMass();
                dominoV0[i] = (m1 - m2) / (m1 + m2) * v0;
                dominoV0[i + 1] = 2 * m1 / (m1 + m2) * v0;
                dominoMoving[i + 1] = 1;
                dominos[i]->setVelocity(dominoV0[i]);
                dominos[i + 1]->setVelocity(dominoV0[i + 1]);
            }
        }

        // Collision domino and button
        if (dominos.back()->getRightUp().getZ() >= model3->getLeftDown().getZ() &&
                dominos.back()->getRightUp().findDistanceToLine(model3->getLeftUp(), model3->getLeftDown()) <= DIST_EPS)
        {
            double v0 = dominos.back()->getVelocity();
            double m1 = dominos.back()->getMass();
            double m2 = model3->getMass();
            dominoV0.back() = (m1 - m2) / (m1 + m2) * v0;
            dominos.back()->setVelocity(dominoV0.back());
            model3->setVelocity(2 * m1 / (m1 + m2) * v0, MU_BUTTON);
        }

        QGraphicsScene *setScene = facade->drawScene(ui->graphicsView->rect());

        if (ui->graphicsView->scene())
            delete ui->graphicsView->scene();
        ui->graphicsView->setScene(setScene);
        QTime end = QTime::currentTime().addMSecs(1);
        while (QTime::currentTime() < end)
        {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 1);
        }
    }
}

void MainWindow::on_pushButton_9_clicked()
{
    facade->getScene()->getModel(0).move(250, 0, 0);
    facade->getScene()->getModel(0).setMass(2);
    facade->getScene()->getModel(0).setAngle(0);

    facade->getScene()->getModel(3).move(350, 150, 0);
    facade->getScene()->getModel(4).move(525 + SPACE_BETWEEN_DOMINO * 10.5, 300, 0);

    facade->getScene()->getModel(2).move(400 + SPACE_BETWEEN_DOMINO * 10.5, 0, 0);
    facade->getScene()->getModel(2).rotateZX(M_PI_2);
    facade->getScene()->getModel(2).setAcceleration(MU_BUTTON);

    for (size_t i = DOMINO_START; i < facade->getScene()->getModelsNum(); i++)
    {
        facade->getScene()->getModel(i).move(400 + SPACE_BETWEEN_DOMINO * (i - DOMINO_START), 0, 0);
        facade->getScene()->getModel(i).setAngle(M_PI_2);
    }
}
